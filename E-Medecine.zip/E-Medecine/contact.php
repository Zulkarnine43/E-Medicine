<?php include 'header.php'; ?>

    <div>
        <h4  style="color: #4cae4c">Address</h4>
        <p style="color: #4cae4c" > Bashiruddin Road <span>Dhaka City.</span></p>
    </div>
    </div>
    <div >
        <div>
            <h4  style="color: #4cae4c">Call Us</h4>
           <span  style="color: #4cae4c">+456789567</span>
        </div>
    </div>
    <div>
        <div >
            <h4  style="color: #4cae4c">Email</h4>
            <p   style="color: #4cae4c">admin@@gmail.com</p>
        </div>
    </div>

<?php include 'footer.php'; ?>