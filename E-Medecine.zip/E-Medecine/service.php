<?php include 'header.php'; ?>

    <section >
        <div>
            <div >
                <h3 > Services</h3>
                <p>As our name implies, Agricultural Services, Inc. is a service oriented company. Our business model requires that we be the best crop production specialists in our trade areas. Agricultural Services does not merely sell crop input commodities. We sell total crop production that provides our customers the best total value for dollars spent on crop inputs!</p>
            </div>
            <div >
                <div>
                    <span ></span>
                    <h4>About medicine Services</h4>
                    <p>Established in 2019, medicine Services is an employee-owned company with a single goal: to help our customers raise the best crops possible. Our agronomy facilities are conveniently located in seven central Nebraska locations.</p>
                </div>
            </div>
        </div>
    </section>

<?php include 'footer.php'; ?>